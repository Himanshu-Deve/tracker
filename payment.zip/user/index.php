<?php
require_once './../session.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'user') {
    header("Location: ../login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100">

    <!-- TOP NAVBAR -->
    <?php include 'user_nav.php'; ?>

    <!-- BODY -->
    <?php include 'user_body.php'; ?>

</body>
</html>
