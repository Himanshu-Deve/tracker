<?php
include '../config/db.php';
$conn = getDB();

session_start();

// 🔐 Page-level protection (ADMIN ONLY)
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// -------------------------------------------
// DELETE USER
// -------------------------------------------
if (isset($_POST['delete_user'])) {
    $id = $_POST['delete_user'];
    $conn->query("DELETE FROM users WHERE id=$id");
    exit("User deleted");
}

// -------------------------------------------
// CREATE USER
// -------------------------------------------
if (isset($_POST['create_user'])) {

    $employee_id = $_POST['employee_id'];
    $name        = $_POST['name'];
    $role        = $_POST['role'];
    $email       = $_POST['email'];
    $contact     = $_POST['contact'];
    $address     = $_POST['address'];
    $password    = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $conn->prepare("
        INSERT INTO users (employee_id, name, role, address, email, contact, password)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->bind_param("sssssss", 
        $employee_id, $name, $role, $address, $email, $contact, $password
    );

    if ($stmt->execute()) { 
        exit("User created successfully!"); 
    }
    exit("Error: " . $stmt->error);
}

// -------------------------------------------
// UPDATE USER
// -------------------------------------------
if (isset($_POST["update_user"])) {

    $id          = $_POST["update_user"];
    $employee_id = $_POST["employee_id"];
    $name        = $_POST["name"];
    $role        = $_POST["role"];
    $email       = $_POST["email"];
    $contact     = $_POST["contact"];
    $address     = $_POST["address"];

    $stmt = $conn->prepare("
        UPDATE users SET employee_id=?, name=?, role=?, email=?, contact=?, address=? WHERE id=?
    ");
    $stmt->bind_param("ssssssi", $employee_id, $name, $role, $email, $contact, $address, $id);

    if ($stmt->execute()) exit("User updated!");
    exit("Update failed");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>User Dashboard</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body class="bg-gray-100">

<div class="flex">
<?php include 'sidebar.php'; ?>

<div class="flex-1 ml-6">

    <h1 class="text-3xl font-bold mb-6">User Management Dashboard</h1>

    <!-- CREATE USER FORM -->
    <div class="bg-white p-6 rounded-xl shadow mb-10">

        <h2 class="text-xl font-semibold mb-4">Create User</h2>

        <form id="createForm">

            <input type="hidden" name="create_user" value="1">

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">

                <input type="text" name="employee_id" placeholder="Employee ID" class="p-3 border rounded" required>
                <input type="text" name="name" placeholder="Name" class="p-3 border rounded" required>
                <input type="text" name="role" placeholder="Role" class="p-3 border rounded" required>
                <input type="email" name="email" placeholder="Email" class="p-3 border rounded">
                <input type="text" name="contact" placeholder="Contact" class="p-3 border rounded">
                <input type="password" name="password" placeholder="Password" class="p-3 border rounded" required>

                <textarea name="address" placeholder="Address" class="p-3 border rounded md:col-span-2"></textarea>

            </div>

            <button class="mt-4 bg-blue-600 text-white px-5 py-3 rounded">Create User</button>

        </form>

        <p id="formMsg" class="mt-3 font-semibold"></p>

    </div>



   <!-- USER LIST -->
<div class="bg-white p-6 rounded-xl shadow">

    <div class="flex justify-between items-center mb-4">
        <h2 class="text-xl font-semibold">User List</h2>

        <!-- SEARCH -->
        <input type="text" id="searchInput" placeholder="Search by name..."
               class="px-3 py-2 border rounded w-60">
    </div>

    <table class="w-full border" id="userTable">
        <thead>
            <tr class="bg-gray-200">
                <th class="p-3 border">#</th>
                <th class="p-3 border">Employee ID</th>
                <th class="p-3 border">Name</th>
                <th class="p-3 border">Role</th>
                <th class="p-3 border">Actions</th>
            </tr>
        </thead>

        <tbody id="tableBody">

            <?php 
            $users = $conn->query("SELECT * FROM users ORDER BY id DESC");
            while ($u = $users->fetch_assoc()): ?>

                <tr class="user-row">
                    <td class="p-3 border"><?= $u["id"] ?></td>
                    <td class="p-3 border"><?= $u["employee_id"] ?></td>
                    <td class="p-3 border name"><?= $u["name"] ?></td>
                    <td class="p-3 border"><?= $u["role"] ?></td>

                    <td class="p-3 border">
                        <button 
                            class="bg-green-600 text-white px-3 py-1 rounded editBtn"
                            data-user='<?= json_encode($u) ?>'>
                            Edit
                        </button>

                        <button 
                            class="bg-red-600 text-white px-3 py-1 rounded deleteBtn"
                            data-id="<?= $u["id"] ?>">
                            Delete
                        </button>
                    </td>
                </tr>

            <?php endwhile; ?>

        </tbody>
    </table>

    <!-- PAGINATION -->
    <div class="flex justify-center mt-4">
        <button id="prevPage" class="px-4 py-2 bg-gray-300 rounded mx-2">Prev</button>
        <span id="pageInfo" class="px-4 py-2"></span>
        <button id="nextPage" class="px-4 py-2 bg-gray-300 rounded mx-2">Next</button>
    </div>

</div>

</div>

</div>
<!-- UPDATE POPUP MODAL -->
<div id="editModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">

    <div class="bg-white w-96 p-6 rounded-xl">

        <h2 class="text-xl font-bold mb-3">Update User</h2>

        <form id="editForm">

            <input type="hidden" name="update_user" id="edit_id">

            <input type="text" id="edit_employee_id" name="employee_id" class="p-2 border w-full mb-2" placeholder="Employee ID">
            <input type="text" id="edit_name" name="name" class="p-2 border w-full mb-2" placeholder="Name">
            <input type="text" id="edit_role" name="role" class="p-2 border w-full mb-2" placeholder="Role">
            <input type="email" id="edit_email" name="email" class="p-2 border w-full mb-2" placeholder="Email">
            <input type="text" id="edit_contact" name="contact" class="p-2 border w-full mb-2" placeholder="Contact">
            <textarea id="edit_address" name="address" class="p-2 border w-full mb-2" placeholder="Address"></textarea>

            <button class="bg-blue-600 text-white px-4 py-2 rounded mt-2">Update</button>
        </form>
    </div>

</div>




<script>
    // ----------------------
// Pagination + Search
// ----------------------
let rowsPerPage = 10;
let currentPage = 1;

function updateTable() {
    let rows = $(".user-row:visible");
    let totalRows = rows.length;
    let totalPages = Math.ceil(totalRows / rowsPerPage);

    $("#pageInfo").text(`Page ${currentPage} of ${totalPages}`);

    rows.hide();
    let start = (currentPage - 1) * rowsPerPage;
    let end = start + rowsPerPage;

    rows.slice(start, end).show();
}

$("#nextPage").click(function () {
    let totalRows = $(".user-row:visible").length;
    let totalPages = Math.ceil(totalRows / rowsPerPage);

    if (currentPage < totalPages) {
        currentPage++;
        updateTable();
    }
});

$("#prevPage").click(function () {
    if (currentPage > 1) {
        currentPage--;
        updateTable();
    }
});

// Search by Name
$("#searchInput").on("input", function () {
    let value = $(this).val().toLowerCase();

    $(".user-row").each(function () {
        let name = $(this).find(".name").text().toLowerCase();
        $(this).toggle(name.includes(value));
    });

    currentPage = 1; // reset to first page after search
    updateTable();
});

// INIT
updateTable();

// CREATE USER
$("#createForm").submit(function(e){
    e.preventDefault();

    $.post("", $(this).serialize(), function(res){
        $("#formMsg").text(res);
        location.reload();
    });
});


// DELETE USER
$(".deleteBtn").click(function(){
    if (!confirm("Delete this user?")) return;

    let id = $(this).data("id");

    $.post("", { delete_user:id }, function(res){
        alert(res);
        location.reload();
    });
});


// OPEN EDIT MODAL
$(".editBtn").click(function () {

    let user = $(this).data("user");

    $("#edit_id").val(user.id);
    $("#edit_employee_id").val(user.employee_id);
    $("#edit_name").val(user.name);
    $("#edit_role").val(user.role);
    $("#edit_email").val(user.email);
    $("#edit_contact").val(user.contact);
    $("#edit_address").val(user.address);

    $("#editModal").removeClass("hidden");
});

// CLOSE MODAL ON OUTSIDE CLICK
$("#editModal").click(function(e){
    if (e.target === this) $(this).addClass("hidden");
});

// UPDATE USER
$("#editForm").submit(function(e){
    e.preventDefault();

    $.post("", $(this).serialize(), function(res){
        alert(res);
        location.reload();
    });
});
</script>

</body>
</html>
