<?php
class Database {

    private $host = "127.0.0.1"; 
    private $username = "root";
    private $password = "";
    private $dbname = "payment_tracker";
    private $port = 3306; // <-- CHANGE THIS TO MATCH XAMPP

    public $conn;

    public function getConnection() {
        $this->conn = new mysqli(
            $this->host,
            $this->username,
            $this->password,
            $this->dbname,
            $this->port
        );

        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }

        return $this->conn;
    }
}

function getDB() {
    return (new Database())->getConnection();
}
?>
