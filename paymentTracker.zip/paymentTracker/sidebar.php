<?php
require_once './session.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$userRole = $_SESSION['user_role']; // server truth
?>

<div class="w-64 h-screen bg-blue-800 text-white p-5 fixed left-0 top-0">

    <!-- Store role in localStorage once -->
    <script>
        if (!localStorage.getItem("user_role")) {
            localStorage.setItem("user_role", "<?= $userRole ?>");
        }
    </script>

    <!-- ADMIN MENU -->
    <div id="adminMenu" class="hidden">
        <h2 class="text-2xl font-bold mb-6">Admin Panel</h2>
        <nav class="space-y-3">
            <a href="attendance.php" class="block p-3 rounded hover:bg-blue-700">Attendance</a>
            <a href="index.php" class="block p-3 rounded hover:bg-blue-700">Create User</a>
            <a href="tracker.php" class="block p-3 rounded hover:bg-blue-700">Payment Tracker</a>
            <a href="logout.php" class="block p-3 rounded hover:bg-blue-700">Logout</a>
        </nav>
    </div>

    <!-- USER MENU -->
    <div id="userMenu" class="hidden">
        <h2 class="text-2xl font-bold mb-6">User Panel</h2>
        <nav class="space-y-3">
            <a href="attendance.php" class="block p-3 rounded hover:bg-blue-700">Attendance</a>
            <a href="my-payments.php" class="block p-3 rounded hover:bg-blue-700">My Payments</a>
            <a href="profile.php" class="block p-3 rounded hover:bg-blue-700">Profile</a>
            <a href="logout.php" class="block p-3 rounded hover:bg-blue-700">Logout</a>
        </nav>
    </div>

</div>

<script>
    const role = localStorage.getItem("user_role");

    if (role === "admin") {
        document.getElementById("adminMenu").classList.remove("hidden");
    } else {
        document.getElementById("userMenu").classList.remove("hidden");
    }
</script>
