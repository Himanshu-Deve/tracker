<?php
include '../config/db.php';
$conn = getDB();
session_start();

// 🔐 Page-level protection (ADMIN ONLY)
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit;
}


/* ====================================================
   HANDLE AJAX REQUESTS
==================================================== */

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {

    /* ---------- ADD PAYMENT ---------- */
    if ($_POST['action'] == 'add_payment') {

        // Fix: assign nullable values to variables first
        $cashPayment = ($_POST['cash_payment'] === "" ? NULL : $_POST['cash_payment']);
        $niPayment = ($_POST['ni_payment'] === "" ? NULL : $_POST['ni_payment']);

        $stmt = $conn->prepare("
        INSERT INTO payments (employee_id, work_start, work_end, cash_payment, ni_payment, payment_status)
        VALUES (?, ?, ?, ?, ?, ?)
    ");

        // d = double (can be NULL)
        // s = string
        // i = integer
        $stmt->bind_param(
            "issdds",
            $_POST['employee_id'],   // i
            $_POST['work_start'],    // s
            $_POST['work_end'],      // s
            $cashPayment,            // d (nullable)
            $niPayment,              // d (nullable)
            $_POST['payment_status'] // s
        );

        echo $stmt->execute() ? "Payment Added Successfully!" : "DB Error: " . $stmt->error;
        exit;
    }

  /* ---------- UPDATE FIELD ---------- */
if ($_POST['action'] == 'update_field') {

    $id = $_POST['id'];
    $field = $_POST['field'];
    $value = trim($_POST['value']);

    $allowed = ["cash_payment", "ni_payment", "payment_status", "work_start", "work_end"];
    if (!in_array($field, $allowed)) {
        echo "Invalid Field!";
        exit;
    }

    // Convert empty fields to NULL
    if ($value === "") {
        $value = NULL;
    }

    // Build query based on nullable value
    if ($value === NULL) {
        $stmt = $conn->prepare("UPDATE payments SET $field=NULL WHERE id=?");
        $stmt->bind_param("i", $id);
    } else {
        $stmt = $conn->prepare("UPDATE payments SET $field=? WHERE id=?");

        // Bind based on field type
        if (in_array($field, ["cash_payment", "ni_payment"])) {
            $stmt->bind_param("di", $value, $id);
        } else {
            $stmt->bind_param("si", $value, $id);
        }
    }

    echo $stmt->execute() ? "Updated" : "DB Error: " . $stmt->error;
    exit;
}

/* ---------- LOAD TABLE WITH PAGINATION ---------- */
if ($_POST['action'] == 'load_table') {

    $search = $_POST['search'] ?? "";
    $status_filter = $_POST['status_filter'] ?? "";
    $employee_id = $_POST['employee_id'] ?? "";
    $page = intval($_POST['page'] ?? 1);
    $limit = 10;
    $offset = ($page - 1) * $limit;

    $where = "WHERE u.name LIKE '%$search%'";

    if ($status_filter != "")
        $where .= " AND p.payment_status='$status_filter'";

    if ($employee_id != "")
        $where .= " AND p.employee_id='$employee_id'";

    // COUNT TOTAL RECORDS
    $countQuery = $conn->query("
        SELECT COUNT(*) AS total
        FROM payments p
        JOIN users u ON u.id = p.employee_id
        $where
    ");
    $total = $countQuery->fetch_assoc()['total'];
    $pages = ceil($total / $limit);

    // FETCH PAGINATED DATA
    $query = $conn->query("
        SELECT p.*, u.name 
        FROM payments p
        JOIN users u ON u.id = p.employee_id
        $where
        ORDER BY p.id DESC
        LIMIT $offset, $limit
    ");

    $rows = "";
    $index = $offset + 1; // TABLE INDEX STARTS FROM 1 FOR EACH PAGE

   while ($r = $query->fetch_assoc()) {

    // Highlight completed payments
    $rowClass = ($r['payment_status'] == 'complete') ? "bg-green-100" : "";

    $rows .= "
<tr class='$rowClass'>
    <td class='p-3 border'>$index</td>
    <td class='p-3 border'>$r[name]</td>

    <td class='p-3 border'>
        <input type='datetime-local' class='updateField p-2 border rounded'
               data-id='$r[id]' data-field='work_start'
               value='" . date("Y-m-d\TH:i", strtotime($r['work_start'])) . "'>
    </td>

    <td class='p-3 border'>
        <input type='datetime-local' class='updateField p-2 border rounded'
               data-id='$r[id]' data-field='work_end'
               value='" . date("Y-m-d\TH:i", strtotime($r['work_end'])) . "'>
    </td>

    <td class='p-3 border'>
        <input type='number' class='updateField p-2 border rounded'
               data-id='$r[id]' data-field='cash_payment'
               value='$r[cash_payment]'>
    </td>

    <td class='p-3 border'>
        <input type='number' class='updateField p-2 border rounded'
               data-id='$r[id]' data-field='ni_payment'
               value='$r[ni_payment]'>
    </td>

    <td class='p-3 border'>
        <select class='updateField p-2 border rounded'
                data-id='$r[id]' data-field='payment_status'>
            <option " . ($r['payment_status'] == 'pending' ? 'selected' : '') . " value='pending'>Pending</option>
            <option " . ($r['payment_status'] == 'complete' ? 'selected' : '') . " value='complete'>Complete</option>
        </select>
    </td>
</tr>
";
    $index++;
}

    // PAGINATION UI
    $pagination = "<div class='flex justify-between mt-4'>";

    $prevDisabled = ($page <= 1) ? "opacity-50 cursor-not-allowed" : "";
    $nextDisabled = ($page >= $pages) ? "opacity-50 cursor-not-allowed" : "";

    $pagination .= "
        <button class='px-4 py-2 bg-gray-200 rounded prevPage $prevDisabled' data-page='".($page-1)."'>Previous</button>
        <span class='font-semibold'>Page $page of $pages</span>
        <button class='px-4 py-2 bg-gray-200 rounded nextPage $nextDisabled' data-page='".($page+1)."'>Next</button>
    </div>";

    echo "
    <table class='w-full bg-white shadow rounded-xl'>
        <tr class='bg-gray-200 font-bold'>
            <th class='p-3 border'>#</th>
            <th class='p-3 border'>Employee</th>
            <th class='p-3 border'>Work Start</th>
            <th class='p-3 border'>Work End</th>
            <th class='p-3 border'>Cash Payment</th>
            <th class='p-3 border'>NI Payment</th>
            <th class='p-3 border'>Status</th>
        </tr>
        $rows
    </table>
    $pagination
";
    exit;
}

}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Payment Tracker</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body class="bg-gray-100">

    <div class="flex">

        <?php include 'sidebar.php'; ?>

        <div class="flex-1 p-6">

            <!-- ---------------------------- -->
            <!--        PAGE HEADER + BTN     -->
            <!-- ---------------------------- -->
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-3xl font-bold">Payment Tracker</h1>
                <button onclick="openAddModal()" class="bg-blue-600 text-white px-5 py-3 rounded shadow">
                    + Add Payment
                </button>
            </div>

            <!-- ---------------------------- -->
            <!--           FILTERS            -->
            <!-- ---------------------------- -->
            <div class="bg-white p-4 shadow rounded-xl mb-5 flex flex-wrap gap-4">

                <!-- Employee Dropdown -->
                <select id="employeeFilter" class="p-3 hidden border rounded w-64">
                    <option value="">All Employees</option>
                    <?php
                    $emp = $conn->query("SELECT id, name FROM users ORDER BY name ASC");
                    while ($e = $emp->fetch_assoc()):
                        ?>
                        <option value="<?= $e['id'] ?>"><?= $e['name'] ?></option>
                    <?php endwhile; ?>
                </select>

                <!-- Search Box -->
                <input id="searchEmployee" type="text" class="p-3 border rounded w-64" placeholder="Search Name">

                <!-- Status Filter -->
                <select id="statusFilter" class="p-3 border rounded">
                    <option value="">All Status</option>
                    <option value="pending">Pending</option>
                    <option value="complete">Complete</option>
                </select>

            </div>

            <!-- ---------------------------- -->
            <!--          TABLE LIST          -->
            <!-- ---------------------------- -->
            <div id="paymentTable"></div>

        </div>
    </div>

    <!-- ========================================================= -->
    <!--                     ADD PAYMENT MODAL                     -->
    <!-- ========================================================= -->
    <div id="addPaymentModal" class="fixed inset-0 bg-black bg-opacity-40 hidden flex items-center justify-center">

        <div class="bg-white w-[90%] md:w-[500px] p-6 rounded-xl shadow-xl relative">

            <h2 class="text-xl font-semibold mb-4">Add Payment</h2>

            <button onclick="closeAddModal()" class="absolute top-2 right-2 text-red-500 text-2xl">✖</button>

            <form id="addPaymentForm">

                <input type="hidden" name="action" value="add_payment">

                <select name="employee_id" class="p-3 border rounded w-full mb-3" required>
                    <option value="">Select Employee</option>
                    <?php
                    $emp = $conn->query("SELECT id, name FROM users ORDER BY name ASC");
                    while ($e = $emp->fetch_assoc()):
                        ?>
                        <option value="<?= $e['id'] ?>"><?= $e['name'] ?></option>
                    <?php endwhile; ?>
                </select>

                <!-- DateTime Picker (Calendar + Clock) -->
                <label class="block font-semibold">Work Start:</label>
                <input type="datetime-local" name="work_start" required class="p-3 border rounded w-full mb-3">

                <label class="block font-semibold">Work End:</label>
                <input type="datetime-local" name="work_end" required class="p-3 border rounded w-full mb-3">

                <input type="number" name="cash_payment" placeholder="Cash Payment (optional)"
                    class="p-3 border rounded w-full mb-3">

                <input type="number" name="ni_payment" placeholder="NI Payment (optional)"
                    class="p-3 border rounded w-full mb-3">

                <select name="payment_status" class="p-3 border rounded w-full mb-3">
                    <option value="pending">Pending</option>
                    <option value="complete">Complete</option>
                </select>

                <button class="mt-4 bg-blue-600 text-white px-5 py-3 rounded w-full">
                    Add Payment
                </button>

            </form>

            <p id="addMsg" class="mt-3 text-green-600"></p>

        </div>
    </div>

    <!-- ========================================================= -->
    <!--                     JAVASCRIPT                            -->
    <!-- ========================================================= -->
    <script>

        function openAddModal() {
            document.getElementById("addPaymentModal").classList.remove("hidden");
        }

        function closeAddModal() {
            document.getElementById("addPaymentModal").classList.add("hidden");
        }
let currentPage = 1;

function loadTable() {
    $.post("", {
        action: "load_table",
        search: $("#searchEmployee").val(),
        status_filter: $("#statusFilter").val(),
        employee_id: $("#employeeFilter").val(),
        page: currentPage
    }, function (data) {
        $("#paymentTable").html(data);
    });
}

loadTable();

// PAGINATION CLICK
$(document).on("click", ".prevPage, .nextPage", function () {
    const page = $(this).data("page");
    if (page >= 1) {
        currentPage = page;
        loadTable();
    }
});

// WHEN FILTER CHANGES → RESET TO PAGE 1
$("#searchEmployee, #statusFilter, #employeeFilter").on("input change", function () {
    currentPage = 1;
    loadTable();
});

// When new payment added → reset to page 1
$("#addPaymentForm").submit(function (e) {
    e.preventDefault();
    $.post("", $(this).serialize(), function (res) {
        $("#addMsg").text(res);
        currentPage = 1;
        loadTable();
        setTimeout(() => closeAddModal(), 700);
    });
});

$(document).on("change", ".updateField", function () {
    let id = $(this).data("id");
    let field = $(this).data("field");
    let value = $(this).val();

    $.post("", {
        action: "update_field",
        id: id,
        field: field,
        value: value
    }, function (res) {
        loadTable(); // refresh row + highlight
    });
});

    </script>

</body>

</html>