<?php
// attendance.php
include '../config/db.php';
$conn = getDB();
session_start();

// 🔐 Page-level protection (ADMIN ONLY)
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Helper: compute hours diff as float
function hours_diff($start, $end) {
    if (!$start || !$end) return 0;
    $s = strtotime($start);
    $e = strtotime($end);
    if ($e <= $s) return 0;
    return ($e - $s) / 3600.0;
}

// ====================================================
// HANDLE AJAX REQUESTS
// All responses are plain text or HTML fragments
// ====================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {

    $action = $_POST['action'];

    // ---------- ADD SHIFT (admin only) ----------
    if ($action === 'add_shift') {
        if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
            echo "Unauthorized";
            exit;
        }

        $employee_id = intval($_POST['employee_id']);
        $shift_start = $_POST['shift_start'];
        $shift_end = $_POST['shift_end'];

        // basic validation
        if (!$employee_id || !$shift_start || !$shift_end) {
            echo "All fields required";
            exit;
        }

        $stmt = $conn->prepare("
            INSERT INTO shifts (employee_id, shift_start_time, shift_end_time)
            VALUES (?, ?, ?)
        ");
        $stmt->bind_param("iss", $employee_id, $shift_start, $shift_end);
        echo $stmt->execute() ? "Shift added" : "DB Error: " . $stmt->error;
        exit;
    }

    // ---------- EDIT SHIFT (admin only) ----------
    if ($action === 'edit_shift') {
        if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
            echo "Unauthorized";
            exit;
        }
        $id = intval($_POST['id']);
        $shift_start = $_POST['shift_start'];
        $shift_end = $_POST['shift_end'];

        $stmt = $conn->prepare("UPDATE shifts SET shift_start_time=?, shift_end_time=? WHERE id=?");
        $stmt->bind_param("ssi", $shift_start, $shift_end, $id);
        echo $stmt->execute() ? "Updated" : "DB Error: " . $stmt->error;
        exit;
    }

    // ---------- DELETE SHIFT (admin only) ----------
    if ($action === 'delete_shift') {
        if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
            echo "Unauthorized";
            exit;
        }
        $id = intval($_POST['id']);
        $stmt = $conn->prepare("DELETE FROM shifts WHERE id=?");
        $stmt->bind_param("i", $id);
        echo $stmt->execute() ? "Deleted" : "DB Error: " . $stmt->error;
        exit;
    }

    // ---------- MARK START (employee or admin) ----------
    if ($action === 'mark_start') {
        // optional: allow admin to mark start for any employee, others only their own
        $id = intval($_POST['id']); // shift id
        $byUser = $_SESSION['user_id'] ?? 0;

        // check ownership
        $q = $conn->prepare("SELECT employee_id FROM shifts WHERE id=?");
        $q->bind_param("i", $id);
        $q->execute();
        $res = $q->get_result()->fetch_assoc();
        if (!$res) { echo "Invalid shift"; exit; }
        $shift_employee = intval($res['employee_id']);

        if ($_SESSION['role'] !== 'admin' && $shift_employee !== $byUser) {
            echo "Unauthorized";
            exit;
        }

        $now = date("Y-m-d H:i:s");
        // set start_day_time only if null (prevent accidental overwrite), admin can force by setting allow param (not implemented)
        $stmt = $conn->prepare("UPDATE shifts SET start_day_time=? WHERE id=?");
        $stmt->bind_param("si", $now, $id);
        echo $stmt->execute() ? "Start marked" : "DB Error: " . $stmt->error;
        exit;
    }

    // ---------- MARK END (employee or admin) ----------
    // When marking end we will compute attendance_status
    if ($action === 'mark_end') {
        $id = intval($_POST['id']);
        $byUser = $_SESSION['user_id'] ?? 0;

        $q = $conn->prepare("SELECT * FROM shifts WHERE id=?");
        $q->bind_param("i", $id);
        $q->execute();
        $r = $q->get_result()->fetch_assoc();
        if (!$r) { echo "Invalid shift"; exit; }
        $shift_employee = intval($r['employee_id']);

        if ($_SESSION['role'] !== 'admin' && $shift_employee !== $byUser) {
            echo "Unauthorized";
            exit;
        }

        $now = date("Y-m-d H:i:s");
        // Determine attendance status:
        // If start_day_time is empty => absent
        // Else compute scheduled_hours and actual_hours:
        //   scheduled_hours = shift_end_time - shift_start_time
        //   actual_hours = now - start_day_time
        // if actual_hours >= scheduled_hours -> present
        // if 0 < actual_hours < scheduled_hours -> half day
        // else absent

        $start_day_time = $r['start_day_time']; // may be null
        $shift_start_time = $r['shift_start_time'];
        $shift_end_time = $r['shift_end_time'];

        $attendance = 'absent';
        if (empty($start_day_time)) {
            $attendance = 'absent';
        } else {
            $scheduled_hours = hours_diff($shift_start_time, $shift_end_time);
            $actual_hours = hours_diff($start_day_time, $now);
            if ($actual_hours >= $scheduled_hours && $scheduled_hours > 0) {
                $attendance = 'present';
            } elseif ($actual_hours > 0 && $actual_hours < $scheduled_hours) {
                $attendance = 'half day';
            } else {
                $attendance = 'absent';
            }
        }

        // Update end time and attendance
        $stmt = $conn->prepare("UPDATE shifts SET employee_end_shift_time=?, attendance_status=? WHERE id=?");
        $stmt->bind_param("ssi", $now, $attendance, $id);
        echo $stmt->execute() ? "End marked ($attendance)" : "DB Error: " . $stmt->error;
        exit;
    }

    // ---------- LOAD TABLE ----------
    if ($action === 'load_table') {
        // optional filters: employee_id, status
        $filter_employee = $_POST['employee_id'] ?? "";
        $filter_status = $_POST['status'] ?? "";
        $search = $_POST['search'] ?? "";

        $where = "WHERE 1=1";
        $params = [];
        if ($filter_employee !== "") {
            $where .= " AND s.employee_id = " . intval($filter_employee);
        }
        if ($filter_status !== "") {
            $where .= " AND s.attendance_status = '" . $conn->real_escape_string($filter_status) . "'";
        }
        if ($search !== "") {
            $where .= " AND u.name LIKE '%" . $conn->real_escape_string($search) . "%'";
        }

        $sql = "SELECT s.*, u.name FROM shifts s JOIN users u ON u.id = s.employee_id $where ORDER BY s.shift_start_time DESC";
        $res = $conn->query($sql);

        // build rows
        $rows = "";
        while ($row = $res->fetch_assoc()) {
            $id = $row['id'];
            $empName = htmlspecialchars($row['name']);
            $shiftStart = $row['shift_start_time'];
            $shiftEnd = $row['shift_end_time'];
            $startDay = $row['start_day_time'];
            $endShift = $row['employee_end_shift_time'];
            $endDay = $row['end_day_time'];
            $status = $row['attendance_status'];

            $rowClass = $status === 'present' ? 'bg-green-100' : ($status === 'half day' ? 'bg-yellow-100' : '');

            // Admin controls
            $isAdmin = (isset($_SESSION['role']) && $_SESSION['role'] === 'admin');

            // Buttons for non-admin (or admin) to mark start/end
            $markStartBtn = "<button class='markStart px-3 py-1 bg-blue-500 text-white rounded text-sm' data-id='$id'>Mark Start</button>";
            $markEndBtn = "<button class='markEnd px-3 py-1 bg-indigo-600 text-white rounded text-sm' data-id='$id'>Mark End</button>";

            // admin edit/delete buttons
            $adminBtns = "";
            if ($isAdmin) {
                $adminBtns = "
                    <button class='editShift px-3 py-1 bg-yellow-400 text-black rounded text-sm' data-id='$id'
                        data-shift_start='$shiftStart' data-shift_end='$shiftEnd'>Edit</button>
                    <button class='deleteShift px-3 py-1 bg-red-500 text-white rounded text-sm' data-id='$id'>Delete</button>
                ";
            }

            $rows .= "
            <tr class='$rowClass'>
                <td class='p-2 border text-sm'>$id</td>
                <td class='p-2 border text-sm'>$empName</td>
                <td class='p-2 border text-sm'>" . date("Y-m-d H:i", strtotime($shiftStart)) . "</td>
                <td class='p-2 border text-sm'>" . date("Y-m-d H:i", strtotime($shiftEnd)) . "</td>
                <td class='p-2 border text-sm'>" . ($endShift ? date("Y-m-d H:i", strtotime($endShift)) : '-') . "</td>
                <td class='p-2 border text-sm'>" . ($startDay ? date("Y-m-d H:i", strtotime($startDay)) : '-') . "</td>
                <td class='p-2 border text-sm'>" .  ($endDay ? date("Y-m-d H:i", strtotime($endDay)) : '-') . "</td>
                <td class='p-2 border text-sm'>" . ucfirst($status) . "</td>
                <td class='p-2 border text-sm flex gap-2'>
                    $markStartBtn
                    $markEndBtn
                    $adminBtns
                </td>
            </tr>
            ";
        }

        echo "
        <table class='w-full bg-white shadow rounded-lg'>
            <thead>
                <tr class='bg-gray-200 text-sm'>
                    <th class='p-2 border'>#</th>
                    <th class='p-2 border'>Employee</th>
                    <th class='p-2 border'>Shift Start</th>
                    <th class='p-2 border'>Shift End</th>
                    <th class='p-2 border'>Employee End Shift</th>
                    <th class='p-2 border'>Start Day Time</th>
                    <th class='p-2 border'>End Day</th>
                    <th class='p-2 border'>Attendance</th>
                    <th class='p-2 border'>Actions</th>
                </tr>
            </thead>
            <tbody>
                $rows
            </tbody>
        </table>
        ";
        exit;
    }
}
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Attendance Management</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body class="bg-gray-100">
    
<?php include 'sidebar.php'; ?>
 <div >
    

    <div class=" max-w-7xl mx-auto">

        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-bold">Attendance / Shift Management</h1>

            <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                <button id="openAdd" class="bg-green-600 text-white px-4 py-2 rounded">+ Add Shift</button>
            <?php endif; ?>
        </div>

        <!-- Filters -->
        <div class="bg-white p-4 rounded-lg shadow mb-4 flex gap-3 items-center">
            <select id="filterEmployee" class="border p-2 rounded">
                <option value="">All Employees</option>
                <?php
                $uQ = $conn->query("SELECT id,name FROM users ORDER BY name ASC");
                while ($u = $uQ->fetch_assoc()):
                ?>
                    <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['name']) ?></option>
                <?php endwhile; ?>
            </select>

            <select id="filterStatus" class="border p-2 rounded">
                <option value="">All Status</option>
                <option value="present">Present</option>
                <option value="absent">Absent</option>
                <option value="half day">Half day</option>
            </select>

            <input id="searchName" class="border p-2 rounded" placeholder="Search name">
            <button id="applyFilter" class="bg-blue-500 text-white px-3 py-2 rounded">Apply</button>
        </div>

        <!-- Table area -->
        <div id="tableArea" class="mb-6"></div>

    </div>
</div>

<!-- Add Shift Modal (Admin) -->
<div id="addModal" class="fixed inset-0 bg-black bg-opacity-40 hidden items-center justify-center">
    <div class="bg-white p-6 rounded-lg w-[95%] md:w-[600px]">
        <h2 class="text-xl font-semibold mb-4">Add Shift</h2>
        <form id="addShiftForm">
            <input type="hidden" name="action" value="add_shift">
            <div class="grid grid-cols-1 gap-3">
                <select name="employee_id" required class="p-2 border rounded">
                    <option value="">Select Employee</option>
                    <?php
                    $uQ = $conn->query("SELECT id,name FROM users ORDER BY name ASC");
                    while ($u = $uQ->fetch_assoc()):
                    ?>
                        <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['name']) ?></option>
                    <?php endwhile; ?>
                </select>
                <label>Shift Start</label>
                <input type="datetime-local" name="shift_start" required class="p-2 border rounded">
                <label>Shift End</label>
                <input type="datetime-local" name="shift_end" required class="p-2 border rounded">
                <div class="flex gap-2">
                    <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded">Save</button>
                    <button type="button" id="closeAdd" class="bg-gray-400 text-white px-4 py-2 rounded">Cancel</button>
                </div>
                <p id="addMsg" class="text-sm text-green-600"></p>
            </div>
        </form>
    </div>
</div>

<!-- Edit Shift Modal (Admin) -->
<div id="editModal" class="fixed inset-0 bg-black bg-opacity-40 hidden items-center justify-center">
    <div class="bg-white p-6 rounded-lg w-[95%] md:w-[600px]">
        <h2 class="text-xl font-semibold mb-4">Edit Shift</h2>
        <form id="editShiftForm">
            <input type="hidden" name="action" value="edit_shift">
            <input type="hidden" name="id" id="editId">
            <div class="grid grid-cols-1 gap-3">
                <label>Shift Start</label>
                <input type="datetime-local" name="shift_start" id="editStart" required class="p-2 border rounded">
                <label>Shift End</label>
                <input type="datetime-local" name="shift_end" id="editEnd" required class="p-2 border rounded">
                <div class="flex gap-2">
                    <button type="submit" class="bg-yellow-500 text-white px-4 py-2 rounded">Update</button>
                    <button type="button" id="closeEdit" class="bg-gray-400 text-white px-4 py-2 rounded">Cancel</button>
                </div>
                <p id="editMsg" class="text-sm text-green-600"></p>
            </div>
        </form>
    </div>
</div>

<script>
$(function(){

    // load table
    function loadTable(){
        $.post('', {
            action: 'load_table',
            employee_id: $('#filterEmployee').val(),
            status: $('#filterStatus').val(),
            search: $('#searchName').val()
        }, function(html){
            $('#tableArea').html(html);
        });
    }
    loadTable();

    $('#applyFilter').on('click', function(){ loadTable(); });

    // Add modal toggle
    $('#openAdd').on('click', function(){ $('#addModal').removeClass('hidden').addClass('flex'); });
    $('#closeAdd').on('click', function(){ $('#addModal').removeClass('flex').addClass('hidden'); $('#addMsg').text(''); $('#addShiftForm')[0].reset(); });

    // Edit modal toggle
    $(document).on('click', '.editShift', function(){
        $('#editId').val($(this).data('id'));

        // convert server datetime to input-friendly format: YYYY-MM-DDTHH:MM
        const s = $(this).data('shift_start');
        const e = $(this).data('shift_end');
        function dtLocal(v){
            if(!v) return '';
            const d = new Date(v.replace(' ', 'T'));
            const pad = (n)=>n.toString().padStart(2,'0');
            return d.getFullYear() + '-' + pad(d.getMonth()+1) + '-' + pad(d.getDate()) + 'T' + pad(d.getHours()) + ':' + pad(d.getMinutes());
        }
        $('#editStart').val(dtLocal(s));
        $('#editEnd').val(dtLocal(e));

        $('#editModal').removeClass('hidden').addClass('flex');
    });
    $('#closeEdit').on('click', function(){ $('#editModal').removeClass('flex').addClass('hidden'); $('#editMsg').text(''); });

    // Add Shift submit
    $('#addShiftForm').on('submit', function(e){
        e.preventDefault();
        $.post('', $(this).serialize(), function(res){
            $('#addMsg').text(res);
            loadTable();
            setTimeout(function(){ $('#addModal').removeClass('flex').addClass('hidden'); $('#addShiftForm')[0].reset(); $('#addMsg').text(''); }, 800);
        });
    });

    // Edit Shift submit
    $('#editShiftForm').on('submit', function(e){
        e.preventDefault();
        $.post('', $(this).serialize(), function(res){
            $('#editMsg').text(res);
            loadTable();
            setTimeout(function(){ $('#editModal').removeClass('flex').addClass('hidden'); $('#editMsg').text(''); }, 800);
        });
    });

    // Delete shift (admin)
    $(document).on('click', '.deleteShift', function(){
        if (!confirm('Delete this shift?')) return;
        const id = $(this).data('id');
        $.post('', { action: 'delete_shift', id: id }, function(res){
            alert(res);
            loadTable();
        });
    });

    // Mark Start (employee or admin)
    $(document).on('click', '.markStart', function(){
        const id = $(this).data('id');
        $.post('', { action: 'mark_start', id: id }, function(res){
            alert(res);
            loadTable();
        });
    });

    // Mark End (employee or admin) -> computes attendance
    $(document).on('click', '.markEnd', function(){
        const id = $(this).data('id');
        $.post('', { action: 'mark_end', id: id }, function(res){
            alert(res);
            loadTable();
        });
    });

});
</script>

</body>
</html>
