<?php 
$title = "About Us"; 
include __DIR__ . "/includes/header.php"; 

// Dummy JSON Data for Company Info
$companyData = json_decode('{
  "company_name": "PrimeProperties",
  "tagline": "Premium Real Estate Advisory & Property Consulting",
  "about": "PrimeProperties is a modern real estate consultancy dedicated to delivering transparent, data-driven and customer-first property solutions across Gurugram and NCR. With a strong focus on quality, verified listings and client satisfaction, we help families, investors, and businesses make informed real estate decisions with confidence.",
  "mission": "To redefine the real estate buying experience through technology, trust, and professionalism.",
  "highlights": [
    "10+ Years of Real Estate Expertise",
    "1000+ Successful Transactions Completed",
    "Specialized in Residential, Commercial & Investment Properties",
    "Trusted by NRI, Corporate & High-Net-Worth Clients"
  ],
  "values": [
    {
      "title": "Transparency",
      "description": "Every listing is verified to ensure accuracy, honesty and clarity for every client."
    },
    {
      "title": "Expert Guidance",
      "description": "We assist clients with detailed market insights and unbiased consultation."
    },
    {
      "title": "Customer First",
      "description": "Your requirement, budget, and long-term value always remain our priority."
    }
  ],
  "locations": [
    {
      "title": "Gurugram",
      "description": "Premium residential and commercial spaces across Golf Course Road, MG Road & NH8.",
      "image": "https://images.unsplash.com/photo-1560523159-74b3f21f6b97?auto=format&fit=crop&w=1200&q=80"
    },
    {
      "title": "Cyber City",
      "description": "Prime corporate & leasing opportunities in the business capital of NCR.",
      "image": "https://images.unsplash.com/photo-1580741572259-c094f8a981c9?auto=format&fit=crop&w=1200&q=80"
    },
    {
      "title": "Luxury Apartments",
      "description": "Exclusive high-rise apartments with modern lifestyle amenities.",
      "image": "https://images.unsplash.com/photo-1501183638710-841dd1904471?auto=format&fit=crop&w=1200&q=80"
    }
  ],
  "team": [
    {
      "name": "Amit Sharma",
      "role": "Founder & Lead Consultant",
      "description": "Amit brings 10+ years of experience delivering real estate solutions for residential & corporate clients."
    },
    {
      "name": "Priya Mehta",
      "role": "Operations Head",
      "description": "Ensures smooth service operations, client onboarding, and documentation handling."
    },
    {
      "name": "Rohit Verma",
      "role": "Property Specialist",
      "description": "Expert in project tours, locality insights & property comparisons."
    }
  ]
}', true);
?>

<!-- HERO -->
<section class="relative">
  <div class="h-[380px] bg-cover bg-center" 
       style="background-image:url('https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1400&q=80');">
    <div class="bg-black bg-opacity-50 h-full w-full flex items-center justify-center text-center px-4">
      <div>
        <h1 class="text-4xl md:text-5xl font-bold text-white">
          About <?= $companyData["company_name"] ?>
        </h1>
        <p class="text-lg md:text-xl text-gray-200 mt-4 max-w-2xl mx-auto">
          <?= $companyData["tagline"] ?>
        </p>
      </div>
    </div>
  </div>
</section>


<!-- ABOUT -->
<section class="max-w-7xl mx-auto py-16 px-4">
  <h2 class="text-3xl font-bold text-gray-900 text-center">Who We Are</h2>
  <p class="mt-6 text-gray-700 max-w-4xl mx-auto text-center leading-relaxed">
    <?= $companyData["about"] ?>
  </p>

  <ul class="mt-10 grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
    <?php foreach ($companyData["highlights"] as $point): ?>
      <li class="flex items-start space-x-3">
        <span class="text-blue-600 text-xl">•</span>
        <p class="text-gray-700"><?= $point ?></p>
      </li>
    <?php endforeach; ?>
  </ul>
</section>


<!-- MISSION -->
<section class="bg-gray-50 py-16 border-y">
  <div class="max-w-7xl mx-auto px-4 text-center">
    <h2 class="text-3xl font-bold text-gray-900">Our Mission</h2>
    <p class="mt-4 text-gray-700 max-w-3xl mx-auto">
      <?= $companyData["mission"] ?>
    </p>
  </div>
</section>


<!-- LOCATIONS WITH IMAGES -->
<section class="max-w-7xl mx-auto py-16 px-4">
  <h2 class="text-3xl font-bold text-gray-900 text-center">Where We Operate</h2>
  <p class="text-gray-600 text-center mt-3 max-w-xl mx-auto">Prime localities we specialize in.</p>

  <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mt-10">
    <?php foreach ($companyData["locations"] as $loc): ?>
      <div class="bg-white rounded-xl shadow overflow-hidden hover:shadow-lg transition">
        <img src="<?= $loc["image"] ?>" alt="<?= $loc["title"] ?>" class="h-48 w-full object-cover">
        <div class="p-6">
          <h3 class="text-lg font-semibold text-gray-900"><?= $loc["title"] ?></h3>
          <p class="mt-2 text-gray-600 text-sm"><?= $loc["description"] ?></p>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</section>


<!-- VALUES -->
<section class="bg-gray-50 py-16 border-t">
  <h2 class="text-3xl font-bold text-gray-900 text-center">Our Core Values</h2>
  <div class="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-7xl mx-auto px-4 mt-10">
    <?php foreach ($companyData["values"] as $value): ?>
      <div class="bg-white rounded-xl shadow-sm p-8 text-center hover:shadow-md transition">
        <h3 class="text-xl font-semibold text-gray-900"><?= $value["title"] ?></h3>
        <p class="mt-3 text-gray-600"><?= $value["description"] ?></p>
      </div>
    <?php endforeach; ?>
  </div>
</section>


<!-- TEAM -->
<section class="max-w-7xl mx-auto py-16 px-4">
  <h2 class="text-3xl font-bold text-gray-900 text-center">Leadership Team</h2>
  <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mt-10">
    <?php foreach ($companyData["team"] as $member): ?>
      <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 hover:shadow-lg transition">
        <h4 class="text-lg font-semibold text-gray-900"><?= $member["name"] ?></h4>
        <p class="text-sm text-blue-600 font-medium"><?= $member["role"] ?></p>
        <p class="mt-3 text-gray-600 text-sm"><?= $member["description"] ?></p>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<?php include __DIR__ . "/includes/footer.php"; ?>
